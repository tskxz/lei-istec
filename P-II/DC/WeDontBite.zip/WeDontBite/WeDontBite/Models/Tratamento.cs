﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeDontBite.Models
{
    public class Tratamento
    {
    }
}
