﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeDontBite.Models
{
    public class Consulta
    {
        private Veterenario _veterenario;
        private Fatura _faatura;
        private Animal _animal;
        private List<Tratamento> _lstTratamento;
        
    }
}
