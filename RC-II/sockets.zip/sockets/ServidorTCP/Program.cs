﻿using System.Net;
using System.Net.Sockets;
using System.Text;

TcpListener servidor = new TcpListener(IPAddress.Any, 5000);
servidor.Start();

Console.WriteLine("Servidor TCP à espera de ligação...");

TcpClient cliente = servidor.AcceptTcpClient();

NetworkStream stream = cliente.GetStream();

byte[] buffer = new byte[1024];
int bytesLidos = stream.Read(buffer, 0, buffer.Length);

string mensagem = Encoding.UTF8.GetString(buffer, 0, bytesLidos);
Console.WriteLine("Recebido: " + mensagem);

string resposta = "Olá cliente, mensagem recebida!";
byte[] dadosResposta = Encoding.UTF8.GetBytes(resposta);
stream.Write(dadosResposta, 0, dadosResposta.Length);

cliente.Close();
servidor.Stop();