﻿using System.Net.Sockets;
using System.Text;

TcpClient cliente = new TcpClient("127.0.0.1", 5000);
NetworkStream stream = cliente.GetStream();

string mensagem = "Olá servidor TCP!";
byte[] dados = Encoding.UTF8.GetBytes(mensagem);
stream.Write(dados, 0, dados.Length);

byte[] buffer = new byte[1024];
int bytesLidos = stream.Read(buffer, 0, buffer.Length);

string resposta = Encoding.UTF8.GetString(buffer, 0, bytesLidos);
Console.WriteLine("Resposta: " + resposta);

cliente.Close();